@echo off
rem ============================================================================
rem  build.bat - build the dashboard exe (thundr-bot.exe)
rem ----------------------------------------------------------------------------
rem  Builds src/ with Wails and copies the result to this folder, keeping the
rem  previous binary as thundr-bot-old.exe. Wails binding generation is known to
rem  fail on some Windows builds ("open %TEMP%\wails.json"), so the script falls
rem  back automatically:
rem     1. wails build -clean
rem     2. wails build -clean -skipbindings   (bindings are already committed)
rem     3. go build (no wails assets, last resort)
rem
rem  Run:  build.bat
rem  Log:  build.log
rem ============================================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "LOG=%ROOT%\build.log"
set "EXE=%ROOT%\thundr-bot.exe"
echo ============================================================================ > "%LOG%"
echo  build %DATE% %TIME% >> "%LOG%"
echo ============================================================================ >> "%LOG%"

title Thundr Bot - build

rem real Windows temp paths (a POSIX TEMP breaks wails/go tooling)
if not exist "%LOCALAPPDATA%\Temp" mkdir "%LOCALAPPDATA%\Temp" >nul 2>&1
set "TEMP=%LOCALAPPDATA%\Temp"
set "TMP=%LOCALAPPDATA%\Temp"
rem System32 FIRST: an MSYS/Git-Bash PATH shadows find.exe and breaks the checks.
set "PATH=%SystemRoot%\System32;%SystemRoot%;%SystemRoot%\System32\Wbem;%PATH%;%ProgramFiles%\Go\bin;%LOCALAPPDATA%\Programs\Go\bin;%USERPROFILE%\go\bin"

echo.
echo  ============================================================
echo   THUNDR BOT - build
echo  ============================================================

rem ------------------------------------------------------------ prerequisites --
where go >nul 2>&1
if errorlevel 1 (
  echo   Go is not installed - running install.bat first.
  call "%ROOT%\install.bat" nopause
  if errorlevel 1 (
    echo   install.bat did not finish cleanly - aborting.
    pause
    exit /b 1
  )
)
where wails >nul 2>&1
if errorlevel 1 (
  echo   wails CLI missing - installing it now.
  go install github.com/wailsapp/wails/v2/cmd/wails@v2.17.0 >> "%LOG%" 2>&1
  set "PATH=%PATH%;%USERPROFILE%\go\bin"
  where wails >nul 2>&1
  if errorlevel 1 (
    echo   wails CLI still missing - run install.bat as administrator.
    pause
    exit /b 1
  )
)

rem -------------------------------------------------------------- sanity gates --
pushd "%ROOT%\src"
echo   [1/4] go vet ...
go vet ./... >> "%LOG%" 2>&1
if errorlevel 1 (
  echo         FAIL - fix the vet errors first:
  type "%LOG%" | findstr /i "\.go:"
  popd
  pause
  exit /b 1
)
echo         ok

echo   [2/4] go test ...
go test ./... >> "%LOG%" 2>&1
if errorlevel 1 (
  echo         FAIL - unit tests failed, see build.log
  popd
  pause
  exit /b 1
)
echo         ok

rem --------------------------------------------------------------------- build --
echo   [3/4] wails build ...
set "BUILT="
if exist "%ROOT%\src\build\bin\thundr-bot.exe" del /q "%ROOT%\src\build\bin\thundr-bot.exe" >nul 2>&1
wails build -clean >> "%LOG%" 2>&1
if exist "%ROOT%\src\build\bin\thundr-bot.exe" set "BUILT=1"
if not defined BUILT (
  echo         binding generation failed - retrying with -skipbindings
  wails build -clean -skipbindings >> "%LOG%" 2>&1
  if exist "%ROOT%\src\build\bin\thundr-bot.exe" set "BUILT=1"
)
if not defined BUILT (
  echo         wails build failed - falling back to plain go build
  go build -ldflags "-w -s -H windowsgui" -o "%ROOT%\src\build\bin\thundr-bot.exe" . >> "%LOG%" 2>&1
  if exist "%ROOT%\src\build\bin\thundr-bot.exe" set "BUILT=1"
)
if not defined BUILT (
  echo         FAIL - nothing was built. Last log lines:
  powershell -NoProfile -Command "Get-Content -Tail 25 '%LOG%'" 2>nul
  popd
  pause
  exit /b 1
)
echo         ok

rem -------------------------------------------------------------------- publish --
echo   [4/4] publishing to %EXE% ...
if exist "%EXE%" (
  rem keep one previous build for rollback
  copy /y "%EXE%" "%ROOT%\thundr-bot-old.exe" >nul 2>&1
)
copy /y "%ROOT%\src\build\bin\thundr-bot.exe" "%EXE%" >nul 2>&1
if errorlevel 1 (
  echo         FAIL - cannot write %EXE%
  echo                Is the dashboard still running? Close it and run build.bat again.
  popd
  pause
  exit /b 1
)
for %%A in ("%EXE%") do echo         ok - %%~nxA  %%~zA bytes  %%~tA
popd

echo   [extra] contract test ...
where node >nul 2>&1
if errorlevel 1 (
  echo         skipped - node not installed
) else (
  node --test "%ROOT%\tests\contract.test.cjs" > "%TEMP%\thundr-contract.log" 2>&1
  if errorlevel 1 (
    echo         FAIL - node --test failed, see %TEMP%\thundr-contract.log
  ) else (
    echo         ok 7/7
  )
)

echo.
echo  ============================================================
echo   BUILD OK - run.bat starts the dashboard
echo  ============================================================
echo.
if /I "%~1"=="nopause" exit /b 0
pause
exit /b 0

rem ---------------------------------------------------------------------------
rem  :sleep N  - wait N seconds without depending on timeout.exe (which fails
rem  when stdin is redirected, e.g. from a script or CI)
rem ---------------------------------------------------------------------------
:sleep
ping -n %1 127.0.0.1 >nul 2>&1
exit /b 0
