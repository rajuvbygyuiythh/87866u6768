@echo off
rem ============================================================================
rem  install.bat - one-shot installer for Thundr Bot (thundr-go)
rem ----------------------------------------------------------------------------
rem  Installs EVERY requirement on a fresh Windows PC and verifies the result.
rem  Every dependency is tried in several ways (winget -> chocolatey -> scoop ->
rem  direct download), so a machine without winget still gets set up.
rem
rem  Requires: Windows 10/11 x64, internet.
rem  Run:      double-click, or:  install.bat
rem  Log:      install.log (next to this file)
rem ============================================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "LOG=%ROOT%\install.log"
set "FAIL=0"
echo ============================================================================ > "%LOG%"
echo  Thundr Bot installer - %DATE% %TIME% >> "%LOG%"
echo ============================================================================ >> "%LOG%"

title Thundr Bot - install

echo.
echo  ============================================================
echo   THUNDR BOT - full installer
echo   folder: %ROOT%
echo  ============================================================
echo.

rem ---------------------------------------------------------------- 0. sanity --
rem A POSIX temp dir (TEMP=/tmp) makes Windows tools fail with "cannot find the
rem path specified", so force real Windows temp paths for this session.
if not exist "%LOCALAPPDATA%\Temp" mkdir "%LOCALAPPDATA%\Temp" >nul 2>&1
set "TEMP=%LOCALAPPDATA%\Temp"
set "TMP=%LOCALAPPDATA%\Temp"
rem System32 FIRST: a Git-Bash/MSYS PATH would otherwise shadow find.exe,
rem timeout.exe and schtasks.exe with POSIX tools and break this script.
set "PATH=%SystemRoot%\System32;%SystemRoot%;%SystemRoot%\System32\Wbem;%PATH%"

rem ------------------------------------------------------- 1. admin (optional) --
rem Chrome / WebView2 installs need admin. Everything else works unprivileged.
net session >nul 2>&1
if %ERRORLEVEL%==0 (
  set "ADMIN=1"
  echo  [i] running as administrator
) else (
  set "ADMIN=0"
  echo  [i] running as a normal user - Chrome/WebView2 install will be skipped if
  echo      they are missing. Close this window and use "Run as administrator"
  echo      if that happens.
)
echo.

rem ------------------------------------------------------------- 2. toolchain --
rem Add the usual install locations up front so a just-installed tool is found
rem without restarting the shell.
set "PATH=%PATH%;%ProgramFiles%\Go\bin;%LOCALAPPDATA%\Programs\Go\bin;%USERPROFILE%\go\bin;%ProgramData%\chocolatey\bin"

echo  [1/7] Go compiler ...
call :ensure_go
if not "!FAIL!"=="0" goto :summary

echo  [2/7] Wails CLI ...
call :ensure_wails

echo  [3/7] Google Chrome ...
call :ensure_chrome

echo  [4/7] WebView2 runtime ...
call :ensure_webview2

echo  [5/7] Node.js [only needed for the contract test] ...
call :ensure_node

echo  [6/7] Go modules + data defaults ...
call :prepare_project

:summary
echo.
echo  ============================================================
echo   VERIFICATION
echo  ============================================================
call :verify
echo.
if "%FAIL%"=="0" (
  echo   RESULT: READY - run  run.bat  to start the dashboard,
  echo           or  build.bat  to rebuild the exe.
) else (
  echo   RESULT: INCOMPLETE - see the FAIL lines above and install.log
)
echo   Log file: %LOG%
echo  ============================================================
echo.
if /I "%~1"=="nopause" exit /b %FAIL%
pause
exit /b %FAIL%

rem ============================================================================
rem  steps
rem ============================================================================

:ensure_go
go version >nul 2>&1
if not errorlevel 1 (
  for /f "tokens=*" %%v in ('go version') do echo       ok: %%v
  exit /b 0
)
echo       go not found - installing [winget/choco/scoop/direct download]
call :try_winget GoLang.Go || call :try_choco golang || call :try_scoop go
if not exist "%ProgramFiles%\Go\bin\go.exe" if not exist "%LOCALAPPDATA%\Programs\Go\bin\go.exe" (
  call :download_go
)
set "PATH=%PATH%;%ProgramFiles%\Go\bin;%LOCALAPPDATA%\Programs\Go\bin;%USERPROFILE%\go\bin"
go version >nul 2>&1
if errorlevel 1 (
  echo       FAIL: Go is still missing. Install it from https://go.dev/dl/ and rerun.
  set "FAIL=1"
  exit /b 1
)
for /f "tokens=*" %%v in ('go version') do echo       installed: %%v
exit /b 0

:ensure_wails
where wails >nul 2>&1
if not errorlevel 1 (
  for /f "tokens=*" %%v in ('wails version 2^>nul') do (
    echo       ok: %%v
    goto :wails_done
  )
)
echo       wails CLI not found - installing [go install]
go install github.com/wailsapp/wails/v2/cmd/wails@v2.17.0 >> "%LOG%" 2>&1
if errorlevel 1 (
  echo       v2.17.0 failed, trying latest
  go install github.com/wailsapp/wails/v2/cmd/wails@latest >> "%LOG%" 2>&1
)
set "PATH=%PATH%;%USERPROFILE%\go\bin"
where wails >nul 2>&1
if errorlevel 1 (
  echo       FAIL: wails CLI not on PATH. Add %%USERPROFILE%%\go\bin to PATH and rerun.
  set "FAIL=1"
  exit /b 1
)
for /f "tokens=*" %%v in ('wails version 2^>nul') do echo       installed: %%v
:wails_done
exit /b 0

:ensure_chrome
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
  echo       ok: %CHROME%
  exit /b 0
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
  set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
  echo       ok: %CHROME%
  exit /b 0
)
if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
  echo       ok: %LOCALAPPDATA%\Google\Chrome\Application\chrome.exe
  exit /b 0
)
echo       chrome not found - installing Google Chrome
call :try_winget Google.Chrome
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" exit /b 0
call :try_choco googlechrome
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" exit /b 0
if "%ADMIN%"=="1" (
  echo       downloading the official standalone installer
  powershell -NoProfile -Command "try { Invoke-WebRequest -Uri 'https://dl.google.com/chrome/install/ChromeStandaloneSetup64.exe' -OutFile '%TEMP%\ChromeSetup.exe' -UseBasicParsing } catch { exit 1 }" >> "%LOG%" 2>&1
  if exist "%TEMP%\ChromeSetup.exe" (
    "%TEMP%\ChromeSetup.exe" /silent /install
    call :sleep 20
    del "%TEMP%\ChromeSetup.exe" >nul 2>&1
  )
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
  echo       installed: Google Chrome
  exit /b 0
)
echo       FAIL: Chrome is required [the bot drives a real Chrome]. Install it,
echo             then rerun install.bat.
set "FAIL=1"
exit /b 1

:ensure_webview2
rem The desktop window needs the WebView2 runtime (built into Windows 11).
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1
if not errorlevel 1 (
  echo       ok: WebView2 runtime present
  exit /b 0
)
reg query "HKCU\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1
if not errorlevel 1 (
  echo       ok: WebView2 runtime present [per-user]
  exit /b 0
)
echo       WebView2 runtime missing - installing
call :try_winget Microsoft.EdgeWebView2Runtime
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1
if not errorlevel 1 exit /b 0
call :try_choco webview2-runtime
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1
if not errorlevel 1 exit /b 0
if "%ADMIN%"=="1" (
  powershell -NoProfile -Command "try { Invoke-WebRequest -Uri 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile '%TEMP%\webview2.exe' -UseBasicParsing } catch { exit 1 }" >> "%LOG%" 2>&1
  if exist "%TEMP%\webview2.exe" (
    "%TEMP%\webview2.exe" /silent /install
    call :sleep 25
    del "%TEMP%\webview2.exe" >nul 2>&1
  )
)
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1
if not errorlevel 1 (
  echo       installed: WebView2 runtime
  exit /b 0
)
echo       WARN: WebView2 runtime still missing. The HTTP dashboard [run.bat server]
echo             works, but the desktop window will not open until it is installed.
exit /b 0

:ensure_node
where node >nul 2>&1
if not errorlevel 1 (
  for /f "tokens=*" %%v in ('node --version 2^>nul') do echo       ok: node %%v
  exit /b 0
)
echo       node not found [optional] - installing Node.js LTS for the contract test
call :try_winget OpenJS.NodeJS.LTS || call :try_choco nodejs-lts || call :try_scoop nodejs-lts
where node >nul 2>&1
if errorlevel 1 (
  echo       WARN: node missing - tests/contract.test.cjs will be skipped [not fatal]
) else (
  for /f "tokens=*" %%v in ('node --version 2^>nul') do echo       installed: node %%v
)
exit /b 0

:prepare_project
if not exist "%ROOT%\data" mkdir "%ROOT%\data"
if not exist "%ROOT%\browser-profiles" mkdir "%ROOT%\browser-profiles"
call :seed_defaults
pushd "%ROOT%\src"
echo       go mod download ...
go mod download >> "%LOG%" 2>&1
if errorlevel 1 (
  echo       FAIL: go mod download failed - check the internet connection / proxy.
  set "FAIL=1"
  popd
  exit /b 1
)
echo       go mod download ok
popd
exit /b 0

:install_watcher
rem The watcher method was removed — the exe opens Chrome directly (single path).
exit /b 0

rem ============================================================================
rem  helpers
rem ============================================================================

:try_winget
where winget >nul 2>&1
if errorlevel 1 exit /b 1
echo         winget install %~1
winget install --id %~1 -e --silent --accept-package-agreements --accept-source-agreements >> "%LOG%" 2>&1
exit /b %ERRORLEVEL%

:try_choco
where choco >nul 2>&1
if errorlevel 1 exit /b 1
echo         choco install %~1 -y
choco install %~1 -y --no-progress >> "%LOG%" 2>&1
exit /b %ERRORLEVEL%

:try_scoop
where scoop >nul 2>&1
if errorlevel 1 exit /b 1
echo         scoop install %~1
scoop install %~1 >> "%LOG%" 2>&1
exit /b %ERRORLEVEL%

:download_go
rem Last resort: ask go.dev for the current version and fetch the MSI.
echo       downloading Go from go.dev
set "GOVER="
for /f "usebackq tokens=1 delims=" %%v in (`curl -s https://go.dev/VERSION?m=text 2^>nul`) do (
  if not defined GOVER set "GOVER=%%v"
)
if not defined GOVER (
  echo       could not read the Go version list
  exit /b 1
)
set "MSI=%TEMP%\%GOVER%.windows-amd64.msi"
powershell -NoProfile -Command "try { Invoke-WebRequest -Uri 'https://go.dev/dl/%GOVER%.windows-amd64.msi' -OutFile '%MSI%' -UseBasicParsing } catch { exit 1 }" >> "%LOG%" 2>&1
if not exist "%MSI%" (
  echo       Go MSI download failed
  exit /b 1
)
if "%ADMIN%"=="1" (
  msiexec /i "%MSI%" /qn /norestart
) else (
  echo       Go needs an administrator install. Run install.bat as administrator,
  echo       or install Go from https://go.dev/dl/ and rerun.
  del "%MSI%" >nul 2>&1
  exit /b 1
)
call :sleep 15
del "%MSI%" >nul 2>&1
exit /b 0

:seed_defaults
rem Create the data files a fresh copy needs. NEVER overwrite existing files -
rem they hold the operator's settings and registered accounts.
if exist "%ROOT%\data\settings.txt" goto :seed_msg
(
  echo bot_mode=visible
  echo workspace_name=thundr
  echo concurrency=2
  echo timeout_seconds=60
  echo use_proxy=false
  echo proxy_scheme=http
  echo chrome_attach_url=http://127.0.0.1:9222
  echo unique_ua_per_browser=true
  echo human_delay=true
  echo headless=false
  echo thread_work_time=900
  echo stranger_wait_time=5
  echo stranger_response_time=2
  echo stranger_response_time_min=2
  echo stranger_response_time_max=5
  echo partner_no_response_secs=10
  echo partner_no_response_secs_min=10
  echo partner_no_response_secs_max=15
  echo reroll_delay_secs=6
  echo reroll_delay_secs_min=6
  echo reroll_delay_secs_max=12
  echo instant_skip_secs=5
  echo search_retry_time=8
  echo search_no_match_secs=75
  echo click_delay_ms=120
  echo submit_delay_ms=150
  echo type_delay_ms=60
  echo type_jitter_ms=40
) > "%ROOT%\data\settings.txt"
echo       created data\settings.txt (defaults)
:seed_msg
if not exist "%ROOT%\data\message_settings.json" (
  > "%ROOT%\data\message_settings.json" echo {
  >> "%ROOT%\data\message_settings.json" echo   "chat_mode": "single",
  >> "%ROOT%\data\message_settings.json" echo   "share_platform": "snap",
  >> "%ROOT%\data\message_settings.json" echo   "folder_path": "",
  >> "%ROOT%\data\message_settings.json" echo   "ai_base_url": "https://api.featherless.ai/v1",
  >> "%ROOT%\data\message_settings.json" echo   "ai_api_key": "",
  >> "%ROOT%\data\message_settings.json" echo   "ai_model": "deepseek-ai/DeepSeek-V3-0324",
  >> "%ROOT%\data\message_settings.json" echo   "api_temperature": 0.9,
  >> "%ROOT%\data\message_settings.json" echo   "api_share_turn": 4
  >> "%ROOT%\data\message_settings.json" echo }
  echo       created data\message_settings.json
)
for %%f in (proxies.txt interests.txt snaps.txt telegram.txt) do (
  if not exist "%ROOT%\data\%%f" type nul > "%ROOT%\data\%%f"
)
if not exist "%ROOT%\data\msg" mkdir "%ROOT%\data\msg"
if not exist "%ROOT%\data\msg\chat.txt" (
  (
    echo hey
    echo asl?
    echo wanna chat
    echo add me on snap %%username%%
  ) > "%ROOT%\data\msg\chat.txt"
  echo       created data\msg\chat.txt [4 sample lines]
)
exit /b 0

:verify
echo   go        :
go version 2>nul || (echo       FAIL & set "FAIL=1")
echo   wails     :
wails version 2>nul || (echo       FAIL & set "FAIL=1")
echo   chrome    :
set "CHROME_OK="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME_OK=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined CHROME_OK if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME_OK=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if defined CHROME_OK (
  echo       ok !CHROME_OK!
) else (
  echo       FAIL & set "FAIL=1"
)
echo   webview2  :
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1 && echo       ok
echo   go build  :
pushd "%ROOT%\src"
go build -o "%TEMP%\thundr-install-check.exe" . >> "%LOG%" 2>&1
if errorlevel 1 (
  echo       FAIL: the project does not compile - see install.log
  set "FAIL=1"
) else (
  echo       ok [compiles]
  del "%TEMP%\thundr-install-check.exe" >nul 2>&1
)
echo   go test   :
go test ./... > "%TEMP%\thundr-gotest.log" 2>&1
if errorlevel 1 (
  echo       FAIL: go test - see %TEMP%\thundr-gotest.log
  set "FAIL=1"
) else (
  echo       ok [all packages pass]
)
popd
echo   contract  :
where node >nul 2>&1
if errorlevel 1 (
  echo       skipped [node missing]
) else (
  node --test "%ROOT%\tests\contract.test.cjs" > "%TEMP%\thundr-contract.log" 2>&1
  if errorlevel 1 (
    echo       FAIL: node --test tests\contract.test.cjs [see %TEMP%\thundr-contract.log]
    set "FAIL=1"
  ) else (
    echo       ok [7/7]
  )
)
exit /b 0

rem ---------------------------------------------------------------------------
rem  :sleep N  - wait N seconds without timeout.exe (which fails when stdin is
rem  redirected, e.g. from a script or CI)
rem ---------------------------------------------------------------------------
:sleep
ping -n %1 127.0.0.1 >nul 2>&1
exit /b 0
