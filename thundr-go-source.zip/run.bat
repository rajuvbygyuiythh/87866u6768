@echo off
rem ============================================================================
rem  run.bat - start the Thundr Bot dashboard (shortcut launcher)
rem ----------------------------------------------------------------------------
rem  run.bat          -> desktop window (Wails app, native window)
rem  run.bat server   -> headless dashboard, opens http://127.0.0.1:8787
rem  run.bat port 9000-> custom port (dashboard/API)
rem  run.bat stop     -> stop every running instance
rem
rem  If thundr-bot.exe does not exist yet it is built first (build.bat).
rem ============================================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "EXE=%ROOT%\thundr-bot.exe"
set "PORT=8787"
set "MODE=desktop"

rem System32 FIRST: an MSYS/Git-Bash PATH shadows find.exe/timeout.exe.
set "PATH=%SystemRoot%\System32;%SystemRoot%;%SystemRoot%\System32\Wbem;%PATH%"


rem ---------------------------------------------------------------- arguments --
:args
if "%~1"=="" goto :args_done
if /I "%~1"=="server" (
  set "MODE=server"
  shift
  goto :args
)
if /I "%~1"=="dump" (
  set "MODE=dump"
  shift
  goto :args
)
if /I "%~1"=="stop"  goto :do_stop
if /I "%~1"=="port"  (
  set "PORT=%~2"
  shift
  shift
  goto :args
)
echo   unknown option: %~1
echo   usage: run.bat [server^|stop^|port N^|dump]
exit /b 1
:args_done

rem --------------------------------------------------------------- preflight --
net session >nul 2>&1
set "ADMIN=0"
if %ERRORLEVEL%==0 set "ADMIN=1"
if not exist "%LOCALAPPDATA%\Temp" mkdir "%LOCALAPPDATA%\Temp" >nul 2>&1
set "TEMP=%LOCALAPPDATA%\Temp"
set "TMP=%LOCALAPPDATA%\Temp"

if not exist "%EXE%" (
  echo   thundr-bot.exe not found - building it first ...
  call "%ROOT%\build.bat" nopause
  if errorlevel 1 (
    echo   Build failed - see build.log
    pause
    exit /b 1
  )
)

tasklist /fi "imagename eq thundr-bot.exe" 2>nul | find /i "thundr-bot.exe" >nul
if not errorlevel 1 (
  echo   A dashboard instance is already running.
  echo   Close it first, or run:  run.bat stop
  if /I not "%MODE%"=="server" pause
  exit /b 0
)


rem tmp dir sanity: a POSIX temp path breaks the child processes
if not exist "%ROOT%\data" mkdir "%ROOT%\data" >nul 2>&1

rem -------------------------------------------------------------------- start --
echo.
echo  ============================================================
if /I "%MODE%"=="server" (
  echo   Thundr Bot - headless dashboard
  echo   http://127.0.0.1:%PORT%
  echo   [close this window to keep it running in the background]
) else if /I "%MODE%"=="dump" (
  echo   Thundr Bot - console build ^(stdout visible^)
) else (
  echo   Thundr Bot - desktop dashboard
)
echo  ============================================================
echo.

if /I "%MODE%"=="server" (
  start "Thundr Bot" "%EXE%" -server -port %PORT%
) else if /I "%MODE%"=="dump" (
  start "Thundr Bot (dump)" cmd /k ""%EXE%" -port %PORT%"
) else (
  start "Thundr Bot" "%EXE%"
)

call :sleep 3
tasklist /fi "imagename eq thundr-bot.exe" 2>nul | find /i "thundr-bot.exe" >nul
if errorlevel 1 (
  echo   WARN: thundr-bot.exe is not running after launch.
  echo         Try  run.bat dump  to see the console output, or run build.bat.
  pause
  exit /b 1
)
if /I "%MODE%"=="server" (
  echo   dashboard running: http://127.0.0.1:%PORT%
  echo   API:              http://127.0.0.1:%PORT%/api/state
  start "" "http://127.0.0.1:%PORT%/"
) else (
  echo   dashboard window opened.
)
echo.
echo   stop it any time with:  run.bat stop
call :sleep 2
exit /b 0

:do_stop
echo   stopping every thundr-bot.exe instance ...
taskkill /IM thundr-bot.exe /F >nul 2>&1
if errorlevel 1 (
  echo   nothing was running.
) else (
  echo   stopped.
)
exit /b 0

rem ---------------------------------------------------------------------------
rem  :sleep N  - wait N seconds without timeout.exe (which fails when stdin is
rem  redirected, e.g. from a script or CI)
rem ---------------------------------------------------------------------------
:sleep
ping -n %1 127.0.0.1 >nul 2>&1
exit /b 0
