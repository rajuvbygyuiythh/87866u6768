package dash

import (
	"testing"
)

// The Profile section still saves name/backend/headless; the launch_mode
// option was removed — the exe itself is the only thing that opens chrome
// now, so the snapshot must NOT advertise a launch_mode field anymore.
func TestSaveSectionProfile(t *testing.T) {
	a := Open(t.TempDir())

	snap, err := a.SaveSection("profile", map[string]any{
		"name":     "default",
		"backend":  "chromedp",
		"headless": false,
	})
	if err != nil {
		t.Fatalf("SaveSection: %v", err)
	}
	settings, ok := snap["settings"].(map[string]any)
	if !ok {
		t.Fatalf("snapshot has no settings: %#v", snap)
	}
	profile, ok := settings["profile"].(map[string]any)
	if !ok {
		t.Fatalf("snapshot has no profile section: %#v", settings)
	}
	if _, exists := profile["launch_mode"]; exists {
		t.Fatalf("profile.launch_mode must not be advertised anymore")
	}
}